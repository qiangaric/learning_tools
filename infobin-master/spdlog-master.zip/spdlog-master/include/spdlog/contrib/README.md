Please put here your contribs. Popular contribs will be moved to main tree after stablization
