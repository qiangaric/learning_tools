int usage(void);
int wel(void);

/* return 1=scan 2=info */
int par_analyze(int cargc,char** cargv);
